# Tablet Media Remote — Hotspot MVP

Two Android apps:

- **Receiver**: install on the tablet. It exposes a local TCP service and uses Android MediaSession/Notification Listener access to control the tablet's active media session.
- **Remote**: install on the S24. It discovers the tablet over the S24's mobile-hotspot network and sends media commands.

## Build APKs without Android Studio

1. Create a free GitHub account and a new empty repository.
2. Upload the entire contents of this folder to the repository (including `.github/workflows/build-apks.yml`).
3. Open the repository's **Actions** tab.
4. Select **Build Tablet Media Remote APKs** and press **Run workflow** if it did not start automatically.
5. When the workflow finishes, open the run and download **TabletMediaRemote-APKs** under Artifacts.
6. Inside the downloaded artifact you will find one APK for `receiver` and one for `remote`.

## Install/use

1. Install the **receiver** APK on the tablet.
2. Install the **remote** APK on the S24.
3. Turn on the S24 mobile hotspot and connect the tablet to it.
4. Open Receiver on the tablet and enable its Notification Listener/media-control access in Android Settings.
5. Open Remote on the S24. It should discover the tablet automatically.

## Notes

- This is a debug build for personal testing, not a Play Store release.
- Android may require permission/settings changes for local-network discovery depending on the OS version.
- The receiver currently controls the first active MediaSession exposed to it. Later versions can add app selection, album artwork, seeking, playlists, and background auto-reconnect.
