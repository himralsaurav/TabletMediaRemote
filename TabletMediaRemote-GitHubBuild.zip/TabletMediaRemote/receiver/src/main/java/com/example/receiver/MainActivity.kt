package com.example.receiver

import android.app.*
import android.content.*
import android.media.AudioManager
import android.media.session.MediaSessionManager
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import java.net.*
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var media: TextView
    private val executor = Executors.newSingleThreadExecutor()
    private var server: ServerSocket? = null
    private var nsd: android.net.nsd.NsdManager? = null
    private var registration: android.net.nsd.NsdManager.RegistrationListener? = null

    override fun onCreate(b: Bundle?) { super.onCreate(b); setContentView(R.layout.activity_main)
        status=findViewById(R.id.status); media=findViewById(R.id.media)
        findViewById<Button>(R.id.settings).setOnClickListener { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        startServer()
    }
    private fun startServer() {
        executor.execute {
            try { server=ServerSocket(0); val port=server!!.localPort
                runOnUiThread { status.text="Ready. Connect this tablet to your S24 hotspot. Port $port" }
                registerService(port)
                while (!server!!.isClosed) { val s=server!!.accept(); executor.execute { handle(s) } }
            } catch(_:Exception) { }
        }
    }
    private fun registerService(port:Int) {
        nsd=getSystemService(NSD_SERVICE) as android.net.nsd.NsdManager
        val info=android.net.nsd.NsdServiceInfo().apply { serviceName="TabletMediaReceiver"; serviceType="_tmremote._tcp"; servicePort=port }
        registration=object:android.net.nsd.NsdManager.RegistrationListener { override fun onServiceRegistered(i:android.net.nsd.NsdServiceInfo){ } override fun onRegistrationFailed(s:android.net.nsd.NsdServiceInfo,e:Int){} override fun onServiceUnregistered(s:android.net.nsd.NsdServiceInfo){} override fun onUnregistrationFailed(s:android.net.nsd.NsdServiceInfo,e:Int){} }
        nsd!!.registerService(info, android.net.nsd.NsdManager.PROTOCOL_DNS_SD, registration)
    }
    private fun handle(sock:Socket) { sock.use { val input=it.getInputStream().bufferedReader(); val out=it.getOutputStream().bufferedWriter(); val line=input.readLine() ?: return
        try { val j=JSONObject(line); val result=execute(j); out.write(result.toString()); out.write("\n"); out.flush() } catch(e:Exception) { out.write(JSONObject().put("error",e.message).toString()+"\n"); out.flush() }
    }}
    private fun execute(j:JSONObject):JSONObject {
        val cmd=j.optString("cmd"); val sm=getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
        val cn=android.content.ComponentName(this, MediaNotificationListener::class.java)
        val sessions=try{sm.getActiveSessions(cn)}catch(_:SecurityException){ emptyList() }
        val c=sessions.firstOrNull()
        when(cmd){"play_pause"->c?.let{if(it.playbackState?.state==android.media.session.PlaybackState.STATE_PLAYING)it.transportControls.pause() else it.transportControls.play()}
            "next"->c?.transportControls?.skipToNext(); "prev"->c?.transportControls?.skipToPrevious(); "volume"->{val a=getSystemService(AUDIO_SERVICE) as AudioManager; val max=a.getStreamMaxVolume(AudioManager.STREAM_MUSIC); val v=(j.optInt("value",50)*max/100.0).toInt().coerceIn(0,max); a.setStreamVolume(AudioManager.STREAM_MUSIC,v,0)} }
        val m=c?.metadata; val title=m?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE) ?: "No media"; val artist=m?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        return JSONObject().put("title",title).put("artist",artist).put("playing",c?.playbackState?.state==android.media.session.PlaybackState.STATE_PLAYING)
    }
    override fun onDestroy(){ try{nsd?.unregisterService(registration)}catch(_:Exception){}; try{server?.close()}catch(_:Exception){}; executor.shutdownNow(); super.onDestroy() }
}
