package com.example.remote

import android.app.*
import android.content.*
import android.net.nsd.*
import android.os.*
import android.widget.*
import java.net.*
import java.io.*
import java.util.concurrent.Executors
import org.json.JSONObject

class MainActivity:Activity(){
 private lateinit var status:TextView; private lateinit var song:TextView; private lateinit var artist:TextView; private lateinit var volume:SeekBar
 private var host:String?=null; private var port=0; private var nsd:NsdManager?=null; private val ex=Executors.newSingleThreadExecutor()
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main);status=findViewById(R.id.status);song=findViewById(R.id.song);artist=findViewById(R.id.artist);volume=findViewById(R.id.volume)
  findViewById<Button>(R.id.play).setOnClickListener{send("play_pause")};findViewById<Button>(R.id.next).setOnClickListener{send("next")};findViewById<Button>(R.id.prev).setOnClickListener{send("prev")};findViewById<Button>(R.id.rescan).setOnClickListener{discover()}
  volume.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(s:SeekBar?,v:Int,f:Boolean){if(f)send("volume",v)};override fun onStartTrackingTouch(s:SeekBar?){};override fun onStopTrackingTouch(s:SeekBar?){}});discover()
 }
 private fun discover(){host=null;port=0;status.text="Searching for tablet…";nsd=getSystemService(NSD_SERVICE) as NsdManager; nsd!!.discoverServices("_tmremote._tcp",NsdManager.PROTOCOL_DNS_SD,object:NsdManager.DiscoveryListener{
  override fun onDiscoveryStarted(s:String){};override fun onDiscoveryStopped(s:String){};override fun onStartDiscoveryFailed(s:String,e:Int){};override fun onStopDiscoveryFailed(s:String,e:Int){};override fun onServiceFound(info:NsdServiceInfo){nsd!!.resolveService(info,object:NsdManager.ResolveListener{override fun onResolveFailed(i:NsdServiceInfo,e:Int){};override fun onServiceResolved(i:NsdServiceInfo){host=i.host.hostAddress;port=i.port;runOnUiThread{status.text="Connected to ${i.serviceName}"};send("state")}})}}})}
 private fun send(cmd:String,value:Int?=null){val h=host?:return; val p=port; ex.execute{try{Socket().use{s->s.connect(InetSocketAddress(h,p),1500);val o=JSONObject().put("cmd",cmd);if(value!=null)o.put("value",value);val w=s.getOutputStream().bufferedWriter();w.write(o.toString()+"\n");w.flush();val r=s.getInputStream().bufferedReader().readLine();val j=JSONObject(r);runOnUiThread{song.text=j.optString("title","No media");artist.text=j.optString("artist","")}}}catch(e:Exception){runOnUiThread{status.text="Tablet connection lost"}}}}
 override fun onDestroy(){try{nsd?.stopServiceDiscovery(object:NsdManager.DiscoveryListener{override fun onDiscoveryStarted(s:String){};override fun onDiscoveryStopped(s:String){};override fun onStartDiscoveryFailed(s:String,e:Int){};override fun onStopDiscoveryFailed(s:String,e:Int){};override fun onServiceFound(i:NsdServiceInfo){};override fun onServiceLost(i:NsdServiceInfo){}})}catch(_:Exception){};ex.shutdownNow();super.onDestroy()}
}
